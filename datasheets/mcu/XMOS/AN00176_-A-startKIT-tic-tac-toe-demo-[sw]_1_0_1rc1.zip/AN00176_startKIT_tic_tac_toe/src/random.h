// Copyright (c) 2016, XMOS Ltd, All rights reserved
extern int my_random(int v);
