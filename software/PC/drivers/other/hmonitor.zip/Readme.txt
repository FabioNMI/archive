   Hmonitor 4.0.2.2 (July 2001)

   OVERVIEW

    This program monitors and displays hardware parameters
collected by the several sensor chips, installed on certain
motherboards. Program can monitor voltages, temperatures
of CPU and motherboard and cooler fans RPMs.

Program can be used under Windows 95/98/ME/NT/2000 operating
systems on Intel-based personal computers.

   KEY FEATURES

   - wide range of MB vendors supported;
   - low resources usage;
   - dynamic system tray status icon;
   - current values are visible as a hint;
   - detailed/warning log files can be produced;
   - customizable alarms/user app. execute;
   - Software cooling (Pro license need);
   - CPU Throttling (Pro license need);
   - ability to display monitoring data from some ASUS VGA cards (PRO license need).
   - ability to use PerfMon to check the data (Commercial license need);

   INSTALLATION

    To perform installation under Windows-NT, you should be logged on
as a member of administrators group.
To begin installation, simply run setup.exe file.
If hmonitor service hadn't been installed, you can install it later
with 'hmonitor.exe /setup' command.
After successful installation, you may launch hmonitor.exe without rebooting.
After rebooting, Hmonitor will start automatically. This option can be
disabled via Hmonitor's system menu.

