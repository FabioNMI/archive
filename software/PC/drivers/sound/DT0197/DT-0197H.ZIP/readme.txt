                 Diamond Technologies Sound System
                  Software Installation and Setup
DOS and Windows 3.1 Drivers Installation:
Setup.exe for Windows 3.1:
The Setup.exe is a Windows 3.1 setup program that installs DOS and Windows
3.1 drivers and utilities.
The user can run Setup.exe by selecting File \ Run... and typing "A:SETUP" on
the command line under Windows 3.1 Program Manager, or by typing "A:SETUP" at
DOS prompt if Windows directory is in the PATH. The Setup.exe copies all the
DOS drivers and utilities to the directory that user specifies during the
setup program.  All the Windows 3.1 drivers and VxDs are copied to the 
Windows system directory.  When the user installs the Diamond Sound System
for the first time the Dtconfig.exe is started to configure the board setting
after the Setup program is finished.
Dosinst.exe for DOS Only installation:
DOS Driver Installation:
The Dosinst.exe is a DOS installation program that copies all the DOS drivers
and utilities to the directory that user specifies.  When the user installs
the Diamond Sound System for the first time the Dtconfig.exe is started to
configure the board setting after the Setup program is finished.  Dosinst.exe
can be installed by typing A:Dosinst.exe at the DOS prompt.
Windows 95 Drinver installation:
1. After user installs the Diamond sound card into the ISA slot in the computer
   and powers on the system, Windows 95 will prompt user with a "New Hardware Found" 
   dialog box since the Diamond sound card is ISA plug and play. To install the
   Windows 95 drivers, select "Driver from disk provided by hardware manufacturer" 
   and click on OK.
2. Insert the "Diamond DOS/Win3.1/Win 95 Drivers and Utilities"
   diskette into the appropriate drive and select that drive from the prompted
   dialog box and click on OK. Windows 95 will copy all the needed files and
   set up all the logic devices on the board automatically.
Windows NT4.0 Driver installation:
1. Start Windows NT and Insert the "Diamond DOS/Win3.1/Win 95/Win NT Drivers
   and Utilities" Disk into A (or B) drive.
2. Click Start-Run, Type in A:\nt\setupnt then click "OK". Back to NT and do
   the following:
   (1) Click "Add..." within CONTROL PANEL/Multimedia/Devices page.
   (2) Choose Unlisted or Updated DRIVER and press "OK".
   (3) Type in C:\dt297\ in Install Driver dialog box then click "Ok".
   (4) Click "Ok" in Add Unlisted or Updated Driver dialog box.
   (5) Continue to finish Installation then Restart Windows NT.
   ** While installing, "Driver Exists" warning message will appear if
      an old version was detected and make sure to select New driver
      (or re-install), otherwise Midi will not function properly.
   ** You may asked to remove the old driver befor update to new one.
      Do the following to remove the old driver:
      a. Double click on 'Audio Devices' in Multimedia/Devices page.
      b. Highlight the Audio device listed then click Remove button.
      c. Repead steps (1) to (5) above.
Troubleshooting:
This appendix provides some tips and information for some of the 
problems you might encounter with your Diamond sound card either
during installation or normal use.
Problems in DOS
Problem:  Cannot load IDE CD-ROM drive.
Cause:    IDE port is not enabled. Check the config.sys file under 
          C: root directory and you should see "device=c:\dtsound
          \cdsetup.sys" before loading your CD-ROM driver. The 
          cdsetup.sys enables the IDE port.
Solution: Run c:\dtsound\dtconfig.exe again and select the CD-ROM
          IDE. When you leave the dtconfig program, device=c:\dtsound
          \cdsetup.sys will be added to config.sys. Make sure 
          that this line is before loading the CD-ROM driver.
Problem:  No sound in a DOS application
Cause:    There could be conflicts in the SB16 settings.
Solution: Rerun the c:\dtsound\dtconfig.exe and try another Port,DMA, or IRQ.
Problems: in Windows 3.1
Problem:  There is no "Sound..." or "MIDI Sequencer..." item 
          under the menu "Device" in the Media Player. Or 
          Mixer application doesn't work.
Cause:    Mixer driver is not loaded.
Solution: Open the SYSTEM.INI file with any file editor. You 
          should see the following: 
          [drivers]
          Wave=dtsndsys.drv
          Aux=dtsndsys.drv
          Mixer=dtsndsys.drv
          Midi=dtopl.drv
          Midi1=dtmpu401.drv
          [386Enh]
          device=dtsndsys.386
          [boot]
          drivers=mmsystem.dll msmixmgr.dll
Problem:  CD audio will not play after the Diamond drivers are installed.
Cause:    The user did not install the [MCI]CD-AUDIO driver.
Solution: Manually add [MCI]CD-AUDIO driver via Control Panel.
Appendix - Driver Reference:
Windows drivers
Diamond sound has three sets of driver and VxD for Windows 95 and Windows
3.1. They are listed below:
                        Sound System Driver     OPL3 Driver     MPU401 Driver
Windows 95 Drivers      Dtsndsys.drv            Dtopl.drv       Dtmpu401.drv
Windows 95 VxDs         Dtsndsys.vxd            Dtsndsys.vxd    Dtsndsys.vxd
Windows 3.1 Drivers     Dtsndsys.drv            Dtopl.drv       Dtmpu401.drv
Windows 3.1 VxDs        Dtsndsys.386            Dtsndsys.386    Dtsndsys.386
The Diamond Sound System, OPL3, and MPU401 drivers are binary compatible with
Windows 95 and Windows 3.1 but the VxDs have different binaries for Windows 95 
and Windows 3.1. The Windows 3.1 VxDs have their extension .386 and the
Windows 95 VxDs have their extension .vxd.
The Windows 95 joystick drivers are the Msjstick.drv and Vjoyd.vxd 
that are Microsoft drivers shipped with Windows 95. Besides these 
eight Windows 95 drivers and VxDs, a Dtsound.inf file is needed for
Windows 95 installation.
For Windows 3.1, drivers and VxDs have to be specified in the system.ini 
file and be loaded when the Windows 3.1 starts. The entries listed in below 
should be added to system.ini file by the setup program.
   [386Enh]                [drivers]
   device = dtsndsys.386   wave  = dtsndsys.drv
                           mixer = dtsndsys.drv
                           aux   = dtsndsys.drv
                           midi  = dtopl.drv
                           midi1 = dtmpu401.drv
DOS drivers:
The DOS drivers include Cdsetup.sys, Dtinit.exe, and Dtconfig.exe.
Cdsetup.sys
The Cdsetup.sys initializes the CD-ROM IDE port before the CD-ROM driver is 
loaded if the user has a CD-ROM drive attached to the IDE port on the Diamond
sound board.  The Cdsetup.sys is specified in the Config.sys file as below.
   device = C:\Dtsound\Cdsetup.sys
   device = C:\Sony\Atapi_cd.sys /D:SNIDE01
The Cdsetup.sys is not a TSR program. There is no harm in running this 
program if there is no CD-ROM drive attached to the IDE port on the Diamond
sound board.
Dtinit.exe
The Dtinit.exe initializes the Diamond sound chip. It is specified in the
Autoexec.bat file followed by a path name as below.
   C:\Dtsound\Dtinit.exe C:\Win31
Dtinit.exe and Dtconfig.exe use the path that follows the Dtinit.exe
in the Autoexec.bat to find the initial data file Dtsound.ini. The Dtsound.ini
follow the standard Windows ini file format. The Dtsound.ini file will be
copied to the Windows directory or the same directory as Dtinit.exe for DOS-only
installation. The Windows sound system driver Dtsndsys.drv and the Windows
Dtconfig.exe
The Dtconfig.exe is a DOS program to help users change the IO, IRQ,
and DMA resource for the Diamond sound system on board devices and to
test the new settings through playing the Stest8.wav, Stest16.wav, 
and Fmtest.mid test files. The new settings are saved in the Dtsound.ini
file which will be used when Dtinit.exe initializes the board.
Information Files:
The is a Windows 95 installation information file for Diamond sound chip
product:
   DTSOUND.INF
They tell Windows 95 where the drivers should be copied during installation.
See the instructions above for Diamond Sound Windows 95 installation.
